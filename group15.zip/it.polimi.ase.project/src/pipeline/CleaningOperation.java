/**
 */
package pipeline;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Cleaning Operation</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pipeline.PipelinePackage#getCleaningOperation()
 * @model abstract="true"
 * @generated
 */
public interface CleaningOperation extends Operation {
} // CleaningOperation
